
function selectCode(a) {
	var e = a.parentNode.parentNode.getElementsByTagName('CODE')[0];
	if (window.getSelection) {
		var s = window.getSelection();
		if (s.setBaseAndExtent) {
			s.setBaseAndExtent(e, 0, e, e.innerText.length - 1);
		}else{
			if (window.opera && e.innerHTML.substring(e.innerHTML.length - 4) == '<BR>') {
				e.innerHTML = e.innerHTML + '&nbsp;';
			}
			var r = document.createRange();
			r.selectNodeContents(e);
			s.removeAllRanges();
			s.addRange(r);
		}
	}else if (document.getSelection) {
		var s = document.getSelection();
		var r = document.createRange();
		r.selectNodeContents(e);
		s.removeAllRanges();
		s.addRange(r);
	}else if (document.selection) {
		var r = document.body.createTextRange();
		r.moveToElementText(e);
		r.select();
	}
}

function popup(url, width, height, name) {
	if (!name) {
		name = '_popup';
	}

	window.open(url.replace(/&amp;/g, '&'), name, 'height=' + height + ',resizable=yes,scrollbars=yes, width=' + width);
	return false;
}

function find_username(url) {
	popup(url, 760, 570, '_usersearch');
	return false;
}


// BTN-RADIO
function initRadioButton() {
	$(".btn-radio-group .btn-radio").click(function() {
		$(this).parents('.btn-radio-group').find('.btn-radio.active').removeClass('active');
		$(this).addClass('active');
		return true;
	});
	
	$(".btn-radio-group .btn-radio input:checked").each(function() {
		$(this).parents('.btn-radio-group').find('.btn-radio.active').removeClass('active');
		$(this).parent().addClass("active");
	})
	
}


/* EDITOR FUNC */
//AJAX FILE UPLOADER
var fileAttachID=0;
var fileAttachCount=0;
function editorAjaxFileUpload(finput) {
	if ($("#fuploadbtn").hasClass("disabled")) {return false;}
	
	$("#fuploadbtn").addClass("disabled");
	fileAttachCount = getAttachCount();
	var fpath = $(finput).val();
	var fuid = 'fuid'+(++fileAttachID);
	var uploadOptions = {
		data: {"preview":"Ajax file upload"},
		success: function(responseText, statusText, xhr, $form) {
			// post-submit callback 
			processResponse(fuid,responseText);
			
			var $cloneinp = $(finput).clone();
			$(finput).after($cloneinp).remove();
			
			$cloneinp.change(function() {
				editorAjaxFileUpload(this);
			})
			$("#fuploadbtn").removeClass("disabled");
			$("#filecomment").val('');
		},
		error: function() {
			$("#fuploadbtn").removeClass("disabled");
			$("#filecomment").val('');
		},
		uploadProgress: function(e,pos,total,percent) {
			fileProgress(fuid,percent);
		}
	};
	crFileRow(fuid,fpath);
	$("#postform").ajaxSubmit(uploadOptions);
}

function initDeleteFile() {
	$("#alist .btn-deletefile").click(function() {
		if ($(this).hasClass("disabled")) {return true;}
		
		$(this).addClass("disabled");
		var dname = $(this).attr("name");
		var fdata={};
			fdata[dname]="Delete file";
		var uploadOptions = {
			data: fdata,
			success: function(responseText, statusText, xhr, $form) {
				// post-submit callback 
				var $restree = $('<div>').html(responseText);
				$("#alist").html($restree.find("#alist").html());
				if ($("#alist .posting-attach-row").size()==0) {$("#attach-list").hide();}
				createAttachThumb();
				initDeleteFile();
			}
		};
		$("#postform").ajaxSubmit(uploadOptions);
		return false;
	});
}

function fileProgress(fuid,percent) {
	$("#"+fuid).find(".progress .bar").css("width",percent+"%");
}
function processResponse(fuid,html) {
	var $restree = $('<div>').html(html);
	var rcount = getAttachCount($restree);
	if (rcount>fileAttachCount) {
		//process OK
		fileAttachCount++;
		var $filerow = $restree.find("#alist .posting-attach-row:eq(0)");
		var fname = $filerow.find("a.attach-link").text();
		var furl = $filerow.find("a.attach-link").attr("href");
		
		$("#alist").html($restree.find("#alist").html());
		
		createAttachThumb();
		initDeleteFile();
	}else{
		//Error while file attach
		$("#"+fuid).removeClass("alert-info").addClass("alert-error").find(".progress").remove();
	}
}
function getAttachCount(data) {
	return (data) ? $(data).find("#alist .posting-attach-row").size():$("#alist .posting-attach-row").size();
}
function getFilename(fpath) {
	return (fpath) ? fpath.replace(/.*\\(.*)$/,"$1"):"";
}
function isImageFile(fname) {
	return fname.match(/\.(jpg|gif|bmp|jpeg|png)$/);
}
function createAttachThumb() {
	if (!!window.FileReader) { //check for ie
		$("#alist .posting-attach-row").each(function() {
			var $filerow = $(this);
			var hasThumb = $filerow.find(".attach-img").size()>0;
			if (!hasThumb) {
				var fname = $filerow.find("a.attach-link").text();
				var furl = $filerow.find("a.attach-link").attr("href");
				if (isImageFile(fname)) {
					$filerow.find("a.attach-link").before('<img class="attach-img" src="'+furl+'"/>');
				}
			}
		});
	}
}
function crFileRow(fuid,fpath) {
	var fname = getFilename(fpath);
	$("#alist").prepend('<div id="'+fuid+'" class="posting-attach-row alert alert-info"><div class="file-row"><div class="pull-left"><div class="row"><div class="span2">'+fname+'</div><div class="span4 progress attach-progress"><div class="bar" style="width: 0%;"></div></div></div></div></div><div class="clearfix"></div></div>');
	$("#attach-list").show();
}

/* AJAX FUNCTIONS */

var aloader = function() {};
aloader.prototype = {
	inited: false,
	init: function() {
		//Init ajax loader
		$(document.body).prepend('<div id="aloading" class="aloading"><span class="aloading-wrap label label-warning"><ins class="icon-refresh icon-white rotate"></ins>&nbsp;Loading...</span></div>');
		this.inited=true;
	},
	show: function() {
		if (!this.inited) {this.init();}
		$("#aloading").show();
	},
	hide: function() {
		if (!this.inited) {this.init();}
		$("#aloading").hide();
	}
}


var historyInit=false;
var lastAsync=0;
var aloader = new aloader();
function async(url,doPushState,defaultEvent,contsel,clbk,pagesel) {
	if (!pagesel) {pagesel=contsel;}
	if (historyInit) {
		if (defaultEvent != null) { 
			defaultEvent.preventDefault(); //Someone passed in a default event, stop it from executing
		}
		
		if (doPushState && history && history.pushState) {  //If we are supposed to push the state or not
			history.pushState({contsel: contsel}, document.title, url); //Push the new state to the browser
		}               
		aloader.show();
		
		var curAsync = (new Date()).getTime();
		lastAsync = curAsync;
		//Make a GET request to the url which was passed in
		$.ajax({
			url: url,
			timeout: 3000,
			success: function(response) {
				if (lastAsync==curAsync) {
					var $npage = $('<div>').html(response);
					var newContent = $npage.find(contsel).html();
					var $contentWrapper = $(pagesel);
					$contentWrapper.html(newContent).hide().fadeIn(200);
					aloader.hide();
					
					if (clbk) {clbk.call(this,$npage);}
					initAsyncGet($contentWrapper);
					if (url.indexOf("#")!=-1) {
						//scrollToHash
						var hash = url.replace(/.*?(#.*)$/g,"$1");
						window.location.href=window.location.href.replace(/(.*?)#.*$/g,"$1")+hash;
					}else{
						scrollTo($contentWrapper);
					}
				}
			},
			error: function() {
				window.location.href=url;
			}
		});
	}else{
		historyInit=true;
	}
}

//form options
var formOptions = {
	beforeSubmit: function(arr, $form, options) {
		aloader.show();
		$form.find("input").prop("disabled",true);
	},
	success: function(responseText, statusText, xhr, $form) {
		// post-submit callback 
		var followlink_sel = $form.attr("data-followlink");
		var rcont_sel = $form.attr("data-rcont");
		var form_rcont_sel = $form.attr("data-form-rcont");
		var $response = $('<div>').html(responseText);
		if (followlink_sel) {
			var $followlink = $response.find(followlink_sel);
			if ($followlink.size()>0) {
				//async get follow link
				async($followlink.attr("href"), true, null,rcont_sel,null);
				return;
			}
		}
		var $rform_cont = $response.find(form_rcont_sel);
		if ($rform_cont.size()>0) {
			$(rcont_sel).hide().html($response.find(form_rcont_sel).html()).fadeIn(300);
		}else{
			$(".mbody").html($response.find(".mbody"));
			scrollTo($(".mbody"));
		}
		aloader.hide();
	}
};

function initAsyncGet(parent) {
	var $prnt = (parent) ? $(parent):$(document.body);
	$prnt.find("a.ajax").bind("click", function (e) { 
		var rcont=$(this).attr("data-rcont");
		var clbk=$(this).attr("data-callback");
		var pushState = ($(this).attr("data-skipstate")=="true") ? false:true;
		if (rcont) {
			async($(this).attr("href"), pushState, e,rcont,(window[clbk]) ? window[clbk](this):null);
		}
	});
	
	//pagination list async
	if ($("#tlist").size()>0) {
		$prnt.find(".topic-actions .pagination-list a").bind("click", function (e) { 
			async($(this).attr("href"), true, e,"#tlist",null);
		});
	}
	
	
	$prnt.find("form.ajaxform").each(function () {
		if ($(this).attr("data-rcont")) {
			$(this).on('submit',function() {
				$(this).find("#message").sync();
			});
			$(this).ajaxForm(formOptions);
			
		}
	});
	
}

function toggleActive(a) {
	$(a).toggleClass("active");
}

function ajaxFormInit(form) {
	if ($(form).attr("data-rcont")) {
		$(form).on('submit',function() {
			$(form).find("#message").sync();
		});
		$(form).ajaxForm(formOptions);
	}
}

function scrollTo(block,force) {
	if (block) {
		var pagescroll = $(window).scrollTop();
		var offset = block.offset();
		if (offset) {
			var blockTop = offset.top;
			
			if (pagescroll>blockTop || force) { //v1.0.2
				$('html, body').scrollTop(blockTop);
			}
			/*
			if (pagescroll>blockTop || force) {
				$('html, body').animate({
					scrollTop: blockTop
				 }, 300);
			}
			*/
		}
	}
}

//browser plugin
(function($){
  $.browser = function() {
    return {
		mozilla: (navigator.userAgent.toLowerCase().indexOf('firefox') > -1 || navigator.userAgent.toLowerCase().indexOf('mozilla') > -1),
		opera: (navigator.userAgent.toLowerCase().indexOf('opera') > -1 || navigator.userAgent.toLowerCase().indexOf('presto') > -1)
	};
  };
})(jQuery);
/* END AJAX FUNCTIONS */

$(document).ready(function() {
	//if (typeof(history.pushState)=="undefined") {return true;}
	initAsyncGet();
	if ($.browser().mozilla || $.browser().opera) {historyInit=true;}
	window.onpopstate = function(e) {
		if (!historyInit || (e && e.state)) {
			async(document.location, false, null,((e && e.state) ? e.state.contsel:null));
		}
	};
}); 



/* REPLY WITH QUOTE */
var slideTime=300;
function replyWithQuote(a) {
	if ($(a).hasClass('disabled') || $("#qrblock").size()==0) {return true;}
	$(".quote-line").show();
	$(a).addClass('disabled').children('i').removeClass('fa-reply').addClass('fa-refresh').addClass('rotate');
	var $postcont = $(a).closest(".row").find(".post-content");
	
	async($(a).attr('href'), false, null,"#message-box",function() {
		$("#qrblock").appendTo($postcont).hide();
		$(".wysibb-body").css("min-height","100px");
		
		$(a).removeClass('disabled').children('i').addClass('fa-reply').removeClass('fa-refresh').removeClass('rotate');
		$("#qrblock").appendTo($postcont).fadeIn(slideTime,function() {
			scrollTo($("#qrblock"));
		});
		$postcont.closest(".row").find(".quote-line").hide();
	});
	
	return false;
}
function postReply() {
	if ($("#message").data("wbb")) {
		$("#message").htmlcode('');
	}else{
		$("#message").val('');
	}
	
	var $pold = $("#tlist .post-content-old").addClass("post-content").removeClass("post-content-old");
	$pold.prev(".post-content").remove();
	$pold.show();
	
	$("#qrblock").appendTo($("#qrblock-wrap")).hide().fadeIn(slideTime,function() {
		scrollTo($("#qrblock"),true);
	});
	return false;
}
/* END REPLY WITH QUOTE */

/* POST EDIT */
function editPost(a) {
	var iconClass="fa-edit";
	if ($(a).hasClass('disabled')) {return true;}
	
	//remove prev edits
	var $pold = $("#tlist .post-content-old").addClass("post-content").removeClass("post-content-old");
	$pold.prev(".post-content").remove();
	$pold.show();
	
	
	var $post = $(a).parents(".post-content");
	var $oldpost = $('<div>').addClass("post-content-old").insertAfter($post).hide().html($post.html());
	
	$(a).addClass('disabled').children('i').removeClass(iconClass).addClass('fa-refresh').addClass('rotate');
	var uid = getUID();
	var $postcont = $(a).parents(".post-content").find(".content").attr("id",uid);
	
	async($(a).attr('href'), false, null,"#postformblock",function($npage) {
		$("#qrblock").appendTo($("#qrblock-wrap")).hide();
		
		$(".wysibb-body").css("min-height","100px");
		
		var $form = $postcont.find("#postform");
		$form.children("*").hide();
		$postcont.find("#editorwrap").appendTo($form).show();
		$postcont.find("#submit-buttons").appendTo($form).show();
		
		var $sb = $form.find("#submit-buttons");
		var fetext = $sb.attr("data-fulleditor");
		var canceltext = $sb.attr("data-cancel");
		$form.find("#submit-buttons input:last-child").after('<a class="btn btn-default" style="margin-left:5px;" href="'+$(a).attr("href")+'">'+fetext+'</a>');
		$form.find("#submit-buttons a:last-child").after('<a class="btn btn-default pull-right" style="margin-left:25px;" href="#" onClick="return cancelEdit(this)">'+canceltext+'</a>');
		$sb.find(".post-buttons").removeClass("center").removeClass("col-sm-10").addClass("col-sm-12").css({"padding-left":"9px"});
		$sb.find("input[name='preview']").hide();
		 
		$(a).removeClass('disabled').children('i').addClass(iconClass).removeClass('fa-refresh').removeClass('rotate');
		$post.closest(".row").find(".quote-line").hide();
		
		//data-rcont="#tlist" data-form-rcont="#msg" data-followlink="#msg a:eq(0)"
		$form.attr("data-rcont","#tlist").attr("data-form-rcont","#msg").attr("data-followlink","#msg a:eq(0)");
		ajaxFormInit($form);
		
	},"#"+uid);
	return false;
}
function cancelEdit(a) {
	var $pbody = $(a).parents('.post-body');
	$pbody.find('.post-content').html($pbody.find('.post-content-old').html());
	$pbody.find('.quote-line').show();
	return false;
}
/* END POST EDIT */
var uid=0;
function getUID() {
	uid++;
	return "uid"+uid;
}



